# Day 14 Content Alignment Fix

**Date:** 2026-03-04
**Issue:** Lectures and labs diverged from the doc plan — AI verification and PPA
methodology segments missing; three curriculum-specified lab exercises not built.

## Problem

The `day14.md` doc plan specifies Day 14 as the **capstone verification session**
where all four cross-cutting threads converge: assertions, AI verification, PPA
analysis, and constraint-based design.

**Lectures — doc plan vs. actual:**

| Doc Plan Segment | Actual Segment | Gap |
|------------------|----------------|-----|
| 1. Assertions — Executable Specifications | d14_s1_assertions.html | ✅ Match |
| 2. AI-Driven Verification Workflows (15 min) | d14_s2_concurrent_assertions.html | ❌ Wrong topic |
| 3. PPA Analysis Methodology (12 min) | d14_s3_functional_coverage.html | ❌ Wrong topic |
| 4. Coverage & the Road Ahead (11 min) | d14_s4_interfaces_road_to_uvm.html | ⚠️ Partial |

**Labs — doc plan vs. actual:**

| Doc Plan Exercise | Actual | Gap |
|-------------------|--------|-----|
| Ex1: Assertion-enhanced UART TX | ex1_uart_assertions | ✅ Match |
| Ex2: UART parity with generate if | *not built* | ❌ Missing |
| Ex3: AI constraint-based TB for project | *not built* | ❌ Missing |
| Ex4: PPA analysis exercise | *not built* | ❌ Missing |
| — | ex2_fsm_assertions | ⚠️ Not in doc plan |
| — | ex3_coverage (worksheet only) | ⚠️ Not in doc plan |

## Fix Applied

### Lectures

| Action | File | Notes |
|--------|------|-------|
| Updated breadcrumbs | `d14_s1_assertions.html` | sed replacements for label text + title banner |
| **NEW** | `d14_s2_ai_verification_workflows.html` | Verification productivity stack, constraint specs, AI prompt engineering |
| **NEW** | `d14_s3_ppa_methodology.html` | PPA report template, analysis paragraphs, design-space exploration, ASIC context |
| **NEW** | `d14_s4_coverage_road_ahead.html` | Coverage concepts, verification maturity scale, UVM/formal roadmap |
| Archived | `d14_s2_concurrent_assertions.html` → archive/ | Content partially merged into s1 and s4 |
| Archived | `d14_s3_functional_coverage.html` → archive/ | Content merged into s4 |
| Archived | `d14_s4_interfaces_road_to_uvm.html` → archive/ | Content merged into s4 |
| Updated | `day14_readme.md` | Aligned segment list |
| Updated | `day14_quiz.md` | Questions now cover AI verification and PPA methodology |
| Retained | `code/day14_ex01_uart_tx_assertions.sv` | Still valid for segment 1 |
| Retained | `diagrams/d14_verification_pyramid.svg` | Still valid |

### Labs

| Action | Directory | Notes |
|--------|-----------|-------|
| Kept | `ex1_uart_assertions/` | Matches doc plan exercise 1 |
| **NEW** | `ex2_uart_parity/` | UART TX with PARITY_EN, generate if, PPA delta |
| **NEW** | `ex3_ai_constraint_tb/` | Constraint spec template, AI workflow instructions |
| **NEW** | `ex4_ppa_analysis/` | Multi-module PPA worksheet + helper Makefile |
| Moved | `ex2_fsm_assertions/` → `supplementary/fsm_assertions/` | Useful but not in doc plan |
| Moved | `ex3_coverage/` → `supplementary/coverage_worksheet/` | Good reference material |
| Updated | `README.md` | Aligned exercise list, added supplementary section |

## Cross-Cutting Thread Impact

All four threads are now properly anchored:

- **AI Verification (Day 4/4):** Ex3 has students write constraint specs for their
  own project modules — the independent application stage of the progressive thread.
- **PPA Analysis:** Ex4 is the dress rehearsal for the final project PPA report.
  Same table format, same analysis paragraph structure.
- **Constraint-Based Design:** Ex2 implements `generate if` for optional parity —
  the only lab exercise where this concept becomes concrete.
- **Verification Maturity:** Segment 4 places students on the Level 1–5 scale.
