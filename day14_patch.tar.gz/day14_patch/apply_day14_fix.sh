#!/usr/bin/env bash
# =============================================================================
# apply_day14_fix.sh — Day 14 Content Alignment Patch
# =============================================================================
# Run from the repo root:  bash day14_patch/apply_day14_fix.sh
#
# What this does:
#   1. Archives old Day 14 lecture segments 2-4 and lab exercises 2-3
#   2. Updates segment 1 breadcrumbs in-place
#   3. Installs new lecture segments aligned with curriculum
#   4. Installs new lab exercises (parity, AI TB, PPA analysis)
#   5. Moves old exercises to supplementary/
# =============================================================================

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE_DIR="$REPO_ROOT/archive/day14_old_sv_verification"

echo "╔══════════════════════════════════════════════╗"
echo "║  Day 14 Content Alignment Patch              ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Repo root: $REPO_ROOT"
echo ""

# ── Verify we're in the right place ──
if [ ! -d "$REPO_ROOT/lectures/week4_day14" ]; then
    echo "ERROR: lectures/week4_day14 not found. Run from repo root."
    exit 1
fi

if [ ! -d "$PATCH_DIR/lectures/week4_day14" ]; then
    echo "ERROR: day14_patch/lectures/week4_day14 not found."
    exit 1
fi

# ── Step 1: Archive old lecture segments 2-4 ──
echo "Step 1: Archiving old lectures..."
mkdir -p "$ARCHIVE_DIR/lectures"

for f in d14_s2_concurrent_assertions.html \
         d14_s3_functional_coverage.html \
         d14_s4_interfaces_road_to_uvm.html; do
    src="$REPO_ROOT/lectures/week4_day14/$f"
    if [ -f "$src" ]; then
        mv "$src" "$ARCHIVE_DIR/lectures/"
        echo "  Archived: $f"
    fi
done

# ── Step 2: Update segment 1 breadcrumbs in-place ──
echo ""
echo "Step 2: Updating segment 1 breadcrumbs..."
S1="$REPO_ROOT/lectures/week4_day14/d14_s1_assertions.html"
if [ -f "$S1" ]; then
    # Update breadcrumb labels to match new segment names
    sed -i 's|>Concurrent Assert<|>AI Verification<|g' "$S1"
    sed -i 's|>Coverage<|>PPA Methodology<|g' "$S1"
    sed -i 's|>Interfaces/UVM<|>Coverage \&amp; Road Ahead<|g' "$S1"
    # Update the day title banner
    sed -i 's|Day 14 · SystemVerilog for Verification|Day 14 · Verification, AI-Driven Testing \&amp; PPA Analysis|g' "$S1"
    echo "  Updated: d14_s1_assertions.html breadcrumbs"
fi

# ── Step 3: Install new lecture segments ──
echo ""
echo "Step 3: Installing new lectures..."

cp "$PATCH_DIR/lectures/week4_day14/d14_s2_ai_verification_workflows.html" \
   "$REPO_ROOT/lectures/week4_day14/"
cp "$PATCH_DIR/lectures/week4_day14/d14_s3_ppa_methodology.html" \
   "$REPO_ROOT/lectures/week4_day14/"
cp "$PATCH_DIR/lectures/week4_day14/d14_s4_coverage_road_ahead.html" \
   "$REPO_ROOT/lectures/week4_day14/"
echo "  Installed: 3 new slide decks"

cp "$PATCH_DIR/lectures/week4_day14/day14_readme.md" "$REPO_ROOT/lectures/week4_day14/"
cp "$PATCH_DIR/lectures/week4_day14/day14_quiz.md"   "$REPO_ROOT/lectures/week4_day14/"
echo "  Installed: updated readme + quiz"

# Retain existing code/ and diagrams/ (they're still valid)
echo "  Retained: code/day14_ex01_uart_tx_assertions.sv, diagrams/d14_verification_pyramid.svg"

# ── Step 4: Archive old lab exercises, move to supplementary ──
echo ""
echo "Step 4: Reorganizing lab exercises..."
mkdir -p "$ARCHIVE_DIR/labs"
mkdir -p "$REPO_ROOT/labs/week4_day14/supplementary/fsm_assertions"
mkdir -p "$REPO_ROOT/labs/week4_day14/supplementary/coverage_worksheet"

# Move ex2_fsm_assertions → supplementary (useful content, not in doc plan)
if [ -d "$REPO_ROOT/labs/week4_day14/ex2_fsm_assertions" ]; then
    cp -r "$REPO_ROOT/labs/week4_day14/ex2_fsm_assertions"/* \
          "$REPO_ROOT/labs/week4_day14/supplementary/fsm_assertions/"
    mv "$REPO_ROOT/labs/week4_day14/ex2_fsm_assertions" "$ARCHIVE_DIR/labs/"
    echo "  Moved: ex2_fsm_assertions → supplementary/fsm_assertions/"
fi

# Move ex3_coverage → supplementary (worksheet is good reference material)
if [ -d "$REPO_ROOT/labs/week4_day14/ex3_coverage" ]; then
    cp -r "$REPO_ROOT/labs/week4_day14/ex3_coverage"/* \
          "$REPO_ROOT/labs/week4_day14/supplementary/coverage_worksheet/"
    mv "$REPO_ROOT/labs/week4_day14/ex3_coverage" "$ARCHIVE_DIR/labs/"
    echo "  Moved: ex3_coverage → supplementary/coverage_worksheet/"
fi

# Archive old README
if [ -f "$REPO_ROOT/labs/week4_day14/README.md" ]; then
    mv "$REPO_ROOT/labs/week4_day14/README.md" "$ARCHIVE_DIR/labs/README.md.old"
fi

# ── Step 5: Install new lab exercises ──
echo ""
echo "Step 5: Installing new labs..."

# New lab README
cp "$PATCH_DIR/labs/week4_day14/README.md" "$REPO_ROOT/labs/week4_day14/"
echo "  Installed: updated README.md"

# New exercises
for ex in ex2_uart_parity ex3_ai_constraint_tb ex4_ppa_analysis; do
    cp -r "$PATCH_DIR/labs/week4_day14/$ex" "$REPO_ROOT/labs/week4_day14/"
    echo "  Installed: $ex/"
done

# ── Step 6: Update course_dev_status.md ──
echo ""
echo "Step 6: Updating course_dev_status.md..."
STATUS_FILE="$REPO_ROOT/docs/course_dev_status.md"
if [ -f "$STATUS_FILE" ]; then
    # Add Day 14 to the remaining work table if not already there
    if grep -q "Day 14 content alignment" "$STATUS_FILE"; then
        echo "  Day 14 entry already exists in dev status."
    else
        # Append after the Day 10 line
        sed -i '/Day 10 content alignment/a | Day 14 content alignment | ✅ Fixed | Lectures \& labs realigned: AI verification + PPA methodology + parity exercise (2026-03-04) |' "$STATUS_FILE"
        echo "  Added Day 14 entry to dev status."
    fi
fi

# ── Done ──
echo ""
echo "════════════════════════════════════════════════"
echo "  Patch applied successfully."
echo ""
echo "  New lectures:    d14_s{2,3,4}_*.html (s1 breadcrumbs updated)"
echo "  New lab exercises: ex2_uart_parity, ex3_ai_constraint_tb, ex4_ppa_analysis"
echo "  Old content:       archive/day14_old_sv_verification/"
echo "  Supplementary:     labs/week4_day14/supplementary/"
echo ""
echo "  Next steps:"
echo "    1. Review the new files"
echo "    2. git add -A && git commit -m 'fix: align Day 14 lectures/labs with curriculum'"
echo "════════════════════════════════════════════════"
